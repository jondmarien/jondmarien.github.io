const canvas = document.getElementById('matrixCanvas');
const ctx = canvas.getContext('2d');

function initMatrix() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const columns = canvas.width / 20;
    const drops = Array.from({ length: columns }).fill(0);

    function drawMatrixRain() {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#ff4d4d';
        ctx.font = '15px monospace';

        for (let i = 0; i < drops.length; i++) {
            const text = String.fromCharCode(0x30A0 + Math.random() * 96);
            ctx.fillText(text, i * 20, drops[i] * 20);

            if (drops[i] * 20 > canvas.height && Math.random() > 0.975) {
                drops[i] = 0;
            }
            drops[i]++;
        }
    }

    setInterval(drawMatrixRain, 33);
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}


class Scoreboard {
    constructor() {
        this.container = document.getElementById('scoreboard');
        this.lastUpdate = null;
        this.isLoading = false;
        initMatrix();
    }

    showLoading() {
        this.isLoading = true;
        this.container.innerHTML = `
            <div class="loading-state">
                <div class="loading-spinner"></div>
                <div class="loading-text">Updating scoreboard...</div>
            </div>
        `;
    }

    showError(message) {
        this.isLoading = false;
        this.container.innerHTML = `
            <div class="error-state">
                <div class="error-icon">⚠️</div>
                <div class="error-message">Error: ${message}</div>
                <button onclick="scoreboard.retryUpdate()">Retry</button>
            </div>
        `;
    }

    async fetchScoreboard() {
        // Temporary verification in scoreboard.js
        console.log('CONFIG at initialization:', CONFIG);

        if (!CONFIG.API_URL) {
            throw new Error('API URL is not defined in config.js');
        }

        //if (!CONFIG.API_TOKEN) {
        //    throw new Error('API token is not defined in config.js');
        //}

        if (CONFIG.DEMO_MODE) {
            // Fallback mock data if demo API is unavailable
            const mockData = [
                { id: 1, name: "Red Team", score: 1500, solves: [] },
                { id: 2, name: "Blue Team", score: 1350, solves: [] },
                { id: 3, name: "0xHackers", score: 1200, solves: [] }
            ];
            
            try {
                const response = await fetch(CONFIG.API_URL);
                return await response.json().data || mockData;
            } catch {
                return mockData; // Use mock data if fetch fails
            }
        }

        try {
            const response = await fetch(CONFIG.API_URL, {
                method: 'GET',
                headers: {
                    'Authorization': CONFIG.API_TOKEN ? `Token ${CONFIG.API_TOKEN}` : '',
                    'Accept': 'application/json',
                    'Cache-Control': 'no-cache'
                }
            });
    
            // Handle common API errors
            if (response.status === 401) {
                throw new Error('Invalid API token - regenerate in CTFd settings');
            }
            
            if (response.status === 404) {
                throw new Error('Scoreboard endpoint not found');
            }
    
            const jsonData = await response.json();
            
            if (jsonData.success && jsonData.data) {
                const teamsArray = Object.values(jsonData.data)
                    .sort((a, b) => b.score - a.score);
                return CONFIG.MAX_TEAMS ? teamsArray.slice(0, CONFIG.MAX_TEAMS) : teamsArray;
            }
            
            return this.getMockData();
        } catch (error) {
            console.error('Fetch error:', error);
            this.showError(error.message);
            return this.getMockData();
        }
    }
    
    getMockData() {
        return [
            { id: 1, name: "Red Team", score: 1500, solves: [] },
            { id: 2, name: "Blue Team", score: 1350, solves: [] },
            { id: 3, name: "0xHackers", score: 1200, solves: [] }
        ];
    }

    renderTeam(team, index) {
        // Validate team data against expected structure
        const validTeam = {...CONFIG.TEAM_DATA_STRUCTURE, ...team};

        // Solve Count
        const solveCount = team.solves ? team.solves.filter(solve => solve.challenge_id !== null).length : 0;        
        
        return `
            <div class="team" id="team-${validTeam.id}">
                <span class="position">#${index + 1}</span>
                <span class="name">${validTeam.name}</span>
                <span class="score">${validTeam.score} points</span>
                <div class="solves-count">${solveCount} solves</div>
        </div>
            </div>
        `;
    }

    async updateScoreboard() {
        if (this.isLoading) return;

        this.showLoading();
        const data = await this.fetchScoreboard();

        if (!data) return;

        try {
            let html = '<div class="scoreboard-container">';
            data.forEach((team, index) => {
                html += this.renderTeam(team, index);
            });
            html += '</div>';

            this.container.innerHTML = html;
            this.lastUpdate = new Date();
            this.isLoading = false;
            
            this.container.insertAdjacentHTML('beforeend', `
                <div class="update-time">
                    Last updated: ${this.lastUpdate.toLocaleTimeString()}
                </div>
            `);
        } catch (error) {
            this.showError('Failed to render scoreboard: ' + error.message);
        }
    }

    retryUpdate() {
        this.updateScoreboard();
    }

    startAutoUpdate() {
        this.updateScoreboard();
        setInterval(() => this.updateScoreboard(), CONFIG.UPDATE_INTERVAL);
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    window.scoreboard = new Scoreboard();
    // Add resize handler to scoreboard.js
window.addEventListener('resize', initMatrix);

    scoreboard.startAutoUpdate();
});
